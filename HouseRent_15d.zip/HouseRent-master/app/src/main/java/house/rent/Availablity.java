package house.rent;

import house.rent.model.Rent;
import house.rent.model.User;

public class Availablity {

    public static User currentUser;
    public static Rent currentRent;
}
